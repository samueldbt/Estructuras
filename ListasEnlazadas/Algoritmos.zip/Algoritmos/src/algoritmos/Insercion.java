/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package algoritmos;

/**
 *
 * @author CENTIC
 */
public class Insercion {
    public void Insercion(int[] vector){
        
        
    }
    public void imprimirVector(int[] vector){
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i] +"");
        }
        
        System.out.println();
    }
}
