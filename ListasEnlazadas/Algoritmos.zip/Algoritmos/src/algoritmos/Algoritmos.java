/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package algoritmos;

/**
 *
 * @author CENTIC
 */
public class Algoritmos {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        int[] vector = {2,3,4,5,6,7,8,9};
        int[] vector2 = {1,2,3,4,5};
        Ordenamiento o = new Ordenamiento();
        o.vector = vector;
        
        //System.out.println("Vector Original");
        //o.imprimirVector();
        
        /*o.burbuja();
        System.out.println("Vector Ordenado burbuja");
        o.imprimirVector();*/
        
        /*o.Insercion();
        System.out.println("Vector Ordenado insercion");
        o.imprimirVector();*/
        
        /*o.ShellSort();
        System.out.println("Vector Ordenado Shellsort");
        o.imprimirVector();*/
        
        o.OrdenamientoIntercalacionSimple(vector, vector2);
        System.out.println("Ordenacion externa");
    }
}
