/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package algoritmos;

/**
 *
 * @author CENTIC
 */
public class Algoritmos {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        int[] vector = {4, 10, 45, 39, 23, 100, 1};
        System.out.println("Vector Original");
        Burbuja o = new Burbuja();
        o.imprimirVector(vector);
        
        System.out.println("Vector Ordenado Burbuja");
        o.burbuja(vector);
        o.imprimirVector(vector)
    }
    
    public void imprimirVector(int[] vector){
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i] +"");
        }
        
        System.out.println();
    }
    
    
}
