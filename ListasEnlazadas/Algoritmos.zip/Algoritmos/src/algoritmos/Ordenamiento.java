/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package algoritmos;
import java.util.Arrays;
/**
 *
 * @author CENTIC
 */
public class Ordenamiento {
    int[] vector;
    
    public void Ordenamiento(int[] vector){
        this.vector = vector;
    }
    
    public void burbuja(){
        int temp;
        int nOperaciones = 0;
        for(int i=1; i<vector.length;i++){
            for(int j=0; j<vector.length-1;j++){
                if(vector[j] > vector[j+1]){
                    temp = vector[j];
                    vector[j] = vector[j+1];
                    vector[j+1] = temp;
                    nOperaciones++;
                }
            }
        }
        System.out.println("Numero de operaciones: "+nOperaciones);
    }
    
    public void Insercion(){//todavia no esta bien creo
        int temp;
        int nOperaciones = 0;
        if(vector.length<=1){
            System.out.println("nada que hacer");
            return;
        }
         
        for(int i=1; i<vector.length; i++){
            for(int j=i;j>0;j--){
                if(vector[j]<vector[j-1]){
                    temp = vector[j];
                    vector[j] = vector[j-1];
                    vector[j-1] = temp;
                    nOperaciones++;
                }else{
                    break;
                }
            }
        }
        System.out.println("Numero de operaciones: "+nOperaciones);
    }
    
    public void ShellSort(){
        int temp;//este es para hacer el cambio de posiciones cuando sea necesario
        int actual_gap = vector.length/2;
        
        while(actual_gap > 0){
            for(int j=0; j<(vector.length-actual_gap); j++){
                if(vector[j] > vector[j+actual_gap]){
                    temp = vector[j];
                    vector[j] = vector[j+actual_gap];
                    vector[j+actual_gap] = temp;
                }
            }
            actual_gap = actual_gap/2;
        }
    } //funciona con 8 elementos, falla con menos o impares
    
    public void CountingSort(){
        int max = Arrays.stream(vector).max().getAsInt();
        int min = Arrays.stream(vector).min().getAsInt();
        
        int[] aux = new int[max - min + 1];
        for(int i=0; i<vector.length; i++){
            aux[vector[i] - min] = aux[vector[i]-min]+1;
        }
        
        for (int i=1; i<aux.length; i++){
            aux[i] = aux[i] + aux[i-1];
        }
        
        int[] salida = new int[vector.length];
        //lo hice pero me quedo todo mal xd
    }
    
    public void imprimirVector(){
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i] +"");
        }
        
        System.out.println();
    }
}
