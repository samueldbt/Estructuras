/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package algoritmos;

/**
 *
 * @author CENTIC
 */
public class Ordenamiento {
    int[] vector;
    
    public void Ordenamiento(int[] vector){
        this.vector = vector;
    }
    
    public void burbuja(){
        int temp;
        int nOperaciones = 0;
        for(int i=1; i<vector.length;i++){
            for(int j=0; j<vector.length-1;j++){
                if(vector[j] > vector[j+1]){
                    temp = vector[j];
                    vector[j] = vector[j+1];
                    vector[j+1] = temp;
                    nOperaciones++;
                }
            }
        }
        System.out.println("Numero de operaciones: "+nOperaciones);
    }
    
    public void Insercion(){//todavia no esta bien creo
        int temp;
        int nOperaciones = 0;
        if(vector.length<=1){
            System.out.println("nada que hacer");
            return;
        }
         
        for(int i=1; i<vector.length; i++){
            for(int j=i;j>0;j--){
                if(vector[j]<vector[j-1]){
                    temp = vector[j];
                    vector[j] = vector[j-1];
                    vector[j-1] = temp;
                    nOperaciones++;
                }else{
                    break;
                }
            }
        }
        System.out.println("Numero de operaciones: "+nOperaciones);
    }
    
    int gap = vector.length / 2;
    public void ShellSort()
    
    public void ShellSort(int actual_gap){
        
        int temp;
        for(int i=0; i<gap; i++){
            if(vector[i] > vector[i+gap]){
                temp = vector[i];
                vector[i] = vector[i+gap];
                vector[i+gap] = temp;
            }
            ShellSort(actual_gap/2);
        }
    }
    
    public void imprimirVector(){
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i] +"");
        }
        
        System.out.println();
    }
}
