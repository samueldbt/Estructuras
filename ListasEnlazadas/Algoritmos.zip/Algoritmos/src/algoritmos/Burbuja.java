/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package algoritmos;

/**
 *
 * @author CENTIC
 */
public class Burbuja {
    public void burbuja(int[] vector){
        int temp;
        
        for(int i=1; i<vector.length;i++){
            for(int j=0; j<vector.length-1;j++){
                if(vector[j] > vector[j+1]){
                    temp = vector[j];
                    vector[j] = vector[j+1];
                    vector[j+1] = temp;
                }
            }
        }
    }
    
    public void imprimirVector(int[] vector){
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i] +"");
        }
        
        System.out.println();
    }
}
