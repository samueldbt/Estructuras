/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pilasconlaspilas;

/**
 *
 * @author CENTIC
 */
public class Nodo {
    public int dato;
    public Nodo siguiente;
    
    public Nodo(int dato){
        this.dato = dato;
        siguiente = null;
    }
}
