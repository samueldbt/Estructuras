/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pilasconlaspilas;

/**
 *
 * @author CENTIC
 */
public class Pila {
    private Nodo cima;
    private int tamaño;
    
    public Pila(){
        cima = null;
        tamaño = 0;
    }
    
    public boolean estaVacia(){
        if(tamaño == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public void peek(){
        if(estaVacia()){
            System.out.println("la pila esta vacia");
        }else{
            System.out.println("el primer elemento de la pila es: "+cima.dato);
        }
    }
    
    public void eliminarPila(){
        if(estaVacia()){
            System.out.println("No existe pila");
        }else{
            int cont=0;
            while(cont <= tamaño){
                pop();
                cont++;
            }
        }
    }
    
    public void push(int val){
        Nodo nuevoNodo = new Nodo(val);
        
        nuevoNodo.siguiente = cima;
        cima = nuevoNodo;
        tamaño++;
    }
    
    public int pop(){
        Nodo aux = cima;
        cima = cima.siguiente;
        tamaño--;
        System.out.println("Se saco de la pila: "+aux.dato);
        return aux.dato;
    }
}
