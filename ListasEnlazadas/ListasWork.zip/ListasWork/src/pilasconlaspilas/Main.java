/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pilasconlaspilas;

/**
 *
 * @author CENTIC
 */
public class Main {
    public static void main(String[] args){
        Pila pilita = new Pila();
        pilita.peek();
        pilita.push(0);
        pilita.peek();
        pilita.push(1);
        pilita.peek();
        pilita.push(2);
        pilita.peek();
        pilita.push(3);
        pilita.peek();
        
        System.out.println("-------------");
        pilita.eliminarPila();
        pilita.peek();
    }
}
