package lista;

public class Lista {
    public Nodo cabeza = null;
    private int tamaño = 0;
    
    public Lista(){
        this.cabeza = null;
        this.tamaño = 0;
    }
    public int getTamaño(){
        return tamaño;
    }
    
    public boolean estaVacia(){
        if(cabeza == null){
            return true;
        }else{
            return false;
        }
    }
    
    /*public void insertarNodoInicio(int dato){
        Nodo nodoIni = new Nodo(dato);
        nodoIni.siguiente = cabeza;
        cabeza = NodoIni;
    }*/
    
    public void agregarEntero(int entero){
        Nodo nodo = new Nodo(entero);
        if(cabeza == null){
            cabeza= nodo;
        }else{
            Nodo nodoTemporal = cabeza;
            this.cabeza = nodo;
            this.cabeza.siguiente = nodoTemporal;
        }   
        tamaño++;
    }
    
    public void insertarNodoFinal(int dato){
        Nodo nodoFin = new Nodo(dato);
        Nodo nodoRecorre = cabeza;
        
        while (nodoRecorre.siguiente != null){
        nodoRecorre = nodoRecorre.siguiente;
        }
        
        nodoRecorre.siguiente = nodoFin;
        tamaño++;
    }
    
    public void insertarNodoEnMedio(int dato, int idx){
        Nodo nodoMetido = new Nodo(dato);
        Nodo nodoRecorre = cabeza;
        
        int cont = 1;
        while (cont <= (idx-1) && nodoRecorre.siguiente != null){
            nodoRecorre = nodoRecorre.siguiente;
            cont++;
        }
        if(cont==(idx-1)){
            nodoMetido.siguiente = nodoRecorre.siguiente;
            nodoRecorre.siguiente = nodoMetido;
        }
        
        nodoMetido.siguiente = nodoRecorre.siguiente;
        nodoRecorre.siguiente = nodoMetido;
        tamaño++;
    }
    
    public void imprimirLista(){
        Nodo nodoRecorre = cabeza;
        
        while(nodoRecorre != null){
            System.out.println(nodoRecorre.dato+" -> ");
            nodoRecorre = nodoRecorre.siguiente;
        }
        System.out.println("NULL");
    }
    
    public void eliminarPrimero(){
        Nodo inicio = cabeza;
        cabeza = inicio.siguiente;
        inicio.siguiente = null;
        tamaño--;
    }
    
    public void eliminarUltimo(){
        Nodo nodoRecorre = cabeza;
        if(cabeza.siguiente == null){
            cabeza = null;
        }else{
            while(nodoRecorre.siguiente.siguiente != null){
            nodoRecorre = nodoRecorre.siguiente;
            }
            if(nodoRecorre.siguiente.siguiente == null){
                nodoRecorre.siguiente = null;
            }
            tamaño--;
        }
    }
    
    public void eliminarCualquiera(int idx){
        Nodo nodoRecorre = cabeza;
        
        int cont = 0;
        while(cont < (idx - 1) && nodoRecorre.siguiente.siguiente != null){
            nodoRecorre = nodoRecorre.siguiente;
            cont++;
        }
        
        Nodo aux = nodoRecorre.siguiente;
        nodoRecorre.siguiente = aux.siguiente;
        aux.siguiente = null;
        
        tamaño--;
    }
    
    //deben mostrar cuantas veces aparece un dato
    public void busquedaPorIndice(int idx, int datoBuscado){
        Nodo nodoRecorre = cabeza;
        int cont = 0;
        int apariciones = 0;
        while(cont < (idx-1) && nodoRecorre.siguiente != null){
            if(nodoRecorre.dato == datoBuscado){
                apariciones++;
            }
        }
        if(apariciones > 0){
            System.out.println("el dato {"+datoBuscado+"} aparece {"+apariciones+"} veces en la lista");
        }else{
            System.out.println("el dato no esta");
        }
    }
}
