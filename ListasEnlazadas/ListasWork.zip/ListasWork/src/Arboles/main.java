/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

/**
 *
 * @author CENTIC
 */
public class main {
    public static void main(String[] args){
        ArbolBinario arbol = new ArbolBinario();
        
        arbol.insertarNodo(6);
        System.out.println("xd");
        arbol.insertarNodo(1);
        System.out.println("xd");
        arbol.insertarNodo(10);
        System.out.println("xd");
        arbol.insertarNodo(8);
        System.out.println("xd");
        arbol.insertarNodo(14);
        System.out.println("xd");
        arbol.insertarNodo(2);
        /*
        System.out.println("---------------------------");
        arbol.imprimirEnAnchura();
        System.out.println("---------------------------");
        arbol.recorrerPreOrden(arbol.raiz);
        System.out.println("---------------------------");
        arbol.recorrerInOrden(arbol.raiz);
        System.out.println("---------------------------");
        arbol.recorrerPostOrden(arbol.raiz);
        */
        
        arbol.busqueda(7);
    }
}
