/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

/**
 *
 * @author CENTIC
 */
public class ArbolBinario {
    Nodo raiz;
    
    public ArbolBinario(){
        this.raiz = null;
    }
    
    public boolean estaVacio(){
        if(raiz == null){
            return true;
        }else{
            return false;
        }
    }
    
    public void insertarNodo(int dato){
        Nodo nuevo = new Nodo(dato);
        Nodo raizAuxiliar = raiz;
        
        if(estaVacio()){
            raiz = nuevo;
        }else{
            if(nuevo.dato >= raizAuxiliar.dato){
                if(raizAuxiliar.hijoDerecho == null){
                    raizAuxiliar.hijoDerecho = nuevo;
                }else{
                    raizAuxiliar = raiz.hijoDerecho;
                    insertarNodo(nuevo.dato);
                }
            }else if(nuevo.dato < raiz.dato){
                if(raizAuxiliar.hijoIzquierdo == null){
                    raizAuxiliar.hijoIzquierdo = nuevo;
                }else{
                    raizAuxiliar = raiz.hijoIzquierdo;
                    insertarNodo(nuevo.dato);
                }
            }
        }
    }
}
