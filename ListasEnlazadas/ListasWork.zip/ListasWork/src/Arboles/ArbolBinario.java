/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;
import java.util.LinkedList;
import java.util.Queue;
/**
 *
 * @author CENTIC
 */
public class ArbolBinario {
    Nodo raiz;
    
    public ArbolBinario(){
        this.raiz = null;
    }
    
    public boolean estaVacio(){
        return raiz == null;
    }
    
    //se puede sobreescribir el metodo para que no salga basura en el main
    //jijijiji muajajajaja
    public void insertarNodo(int dato){
        insertarNodo(dato, null);
    }
    
    public void insertarNodo(int dato, Nodo raizActual){
        Nodo nuevo = new Nodo(dato);
        
        if(estaVacio() && raizActual == null){
            this.raiz = nuevo;
            System.out.println("Se puso La raiz");
        }else{
            if(raizActual == null){
                raizActual = this.raiz;
                insertarNodo(nuevo.dato, raizActual);
            }else{
                if(nuevo.dato >= raizActual.dato){
                    if(raizActual.hijoDerecho == null){
                        raizActual.hijoDerecho = nuevo;
                        System.out.println("Se puso un hijo derecho");
                    }else{
                        raizActual = raizActual.hijoDerecho;
                        insertarNodo(nuevo.dato, raizActual);
                    }
                }else if(nuevo.dato < raizActual.dato){
                    if(raizActual.hijoIzquierdo == null){
                        raizActual.hijoIzquierdo = nuevo;
                        System.out.println("Se puso un hijo izquierdo");
                    }else{
                        raizActual = raizActual.hijoIzquierdo;
                        insertarNodo(nuevo.dato, raizActual);
                    }
                }
            }
        }
    }
    
    public void insertarNodoSecuencialmente(int dato){
        Nodo nuevo = new Nodo(dato);
        
        if(raiz == null){
            raiz = nuevo;
        }else{
            Nodo recorre = raiz;
            Nodo padre;
            while(true){
                padre = recorre;
                if(dato < recorre.dato){
                    recorre = recorre.hijoIzquierdo;
                    if(recorre == null){
                        padre.hijoIzquierdo = nuevo;
                        return;
                    }
                }
                else{
                    recorre = recorre.hijoDerecho;
                    if(recorre == null){
                    padre.hijoDerecho = nuevo;
                    return;
                    }
                }
            }
        }
    }
    
    public void imprimirEnAnchura(){
        if(estaVacio()){
            System.out.println("El arbol esta vacio");
        }else{
            Queue<Nodo> nodos = new LinkedList<>();
            nodos.add(raiz);
            
            while(!nodos.isEmpty()){
                Nodo nodo = nodos.poll();
                
                System.out.println(" "+nodo.dato);
                
                if(nodo.hijoIzquierdo != null){
                    nodos.add(nodo.hijoIzquierdo);
                }
                
                if(nodo.hijoDerecho != null){
                    nodos.add(nodo.hijoDerecho);
                }
            }
        }
    }
    
    public void recorrerPreOrden(Nodo recorre){
        if (recorre!= null){
            System.out.println(recorre.dato);
            recorrerPreOrden(recorre.hijoIzquierdo);
            recorrerPreOrden(recorre.hijoDerecho); 
        }
    }
    
    public void recorrerInOrden(Nodo recorre){
        if (recorre!= null){
            recorrerInOrden(recorre.hijoIzquierdo);
            System.out.println(recorre.dato);
            recorrerInOrden(recorre.hijoDerecho); 
        }
    }
    
    public void recorrerPostOrden(Nodo recorre){
        if (recorre!= null){
            recorrerPostOrden(recorre.hijoIzquierdo);
            recorrerPostOrden(recorre.hijoDerecho); 
            System.out.println(recorre.dato);
        }
    }
    
    public void busqueda(int dato){
        busqueda(dato, this.raiz);
    }
    
    public void busqueda(int dato, Nodo raizTemporal){
        if(estaVacio() || raizTemporal == null){
            System.out.println("no esta el nodo");
        }else{
            if(dato == raizTemporal.dato){
                System.out.println("existe");
            }else if(dato > raizTemporal.dato){
                raizTemporal = raizTemporal.hijoDerecho;
                busqueda(dato, raizTemporal);
            }else if(dato < raizTemporal.dato){
                raizTemporal = raizTemporal.hijoIzquierdo;
                busqueda(dato, raizTemporal);
            }
        }
    }
    
    public void casosDeEliminacion(Nodo nodoParaEliminar){
        Nodo nodoRecorre = this.raiz;
        
        if(nodoParaEliminar.hijoDerecho == null && nodoParaEliminar.hijoIzquierdo == null){
            nodoParaEliminar = null;
        }else if(nodoParaEliminar.hijoIzquierdo == null){
            while(nodoRecorre.hijoDerecho != nodoParaEliminar){
                
            }
        }else if(nodoParaEliminar.hijoDerecho == null){
            
        }
    }
    
    public void eliminar(int dato, Nodo raizTemporal){
        //se reemplaza la raiz por el valor mas pequeño
        //de su subarbol derecho
       
        if(estaVacio()){
            System.out.println("no hay nada que eliminar");
        }else if(raizTemporal.dato == dato){ //caso base, se elimina el nodo presente
            casosDeEliminacion(raizTemporal); 
        }else if(dato > raizTemporal.dato){
            raizTemporal = raizTemporal.hijoDerecho;
            eliminar(dato, raizTemporal);
        }else if(dato < raizTemporal.dato){
            raizTemporal = raizTemporal.hijoIzquierdo;
            eliminar(dato, raizTemporal);
        }
    }    
    
    public void reflejar(Nodo raiz){
        if(raiz == null){
            System.out.println("no hay arbol");;
        }
            Nodo temporal = raiz.hijoDerecho;
            raiz.hijoDerecho = raiz.hijoIzquierdo;
            raiz.hijoIzquierdo = temporal;
            reflejar(raiz.hijoDerecho);
            reflejar(raiz.hijoIzquierdo);
    }
}
