package listaswork;

public class ListasWork {

    public static void main(String[] args) {
        // TODO code application logic here
        Lista lista = new Lista();
        lista.agregarEntero(0);
        lista.agregarEntero(1);
        lista.agregarEntero(2);
        lista.agregarEntero(3);
        lista.agregarEntero(4);

        lista.imprimirLista();
    }
}
