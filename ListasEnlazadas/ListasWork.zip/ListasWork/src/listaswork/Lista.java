package listaswork;

public class Lista {
    public Nodo cabeza = null;
    
    public Lista(){
        this.cabeza = null;
    }
    
    public void agregarEntero(int entero){
        Nodo nodo = new Nodo(entero);
        if(cabeza == null){
            cabeza= nodo;
        }else{
            Nodo nodoTemporal = cabeza;
            this.cabeza = nodo;
            this.cabeza.siguiente = nodoTemporal;
        }   
    }
    
    public void insertarNodoFinal(int dato){
        Nodo nodoFin = new Nodo(dato);
        Nodo nodoRecorre = cabeza;
        
        while (nodoRecorre != null){
        nodoRecorre = nodoRecorre.siguiente;
        }
        
        nodoRecorre.siguiente = nodoFin;
    }
    
    public void insertarNodoEnMedio(int dato, int idx){
        Nodo nodoMetido = new Nodo(dato);
        Nodo nodoRecorre = cabeza;
        
        int cont = 0;
        while (cont < idx && nodoRecorre.siguiente != null){
            nodoRecorre = nodoRecorre.siguiente;
            cont++;
        }
        
        
        nodoMetido.siguiente = nodoRecorre.siguiente;
        nodoRecorre.siguiente = nodoMetido;
    }
    
    public void imprimirLista(){
        Nodo nodoRecorre = cabeza;
        
        while(nodoRecorre != null){
            System.out.println(nodoRecorre.dato+" -> ");
            nodoRecorre = nodoRecorre.siguiente;
        }
        System.out.println("NULL");
    }
}
