/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListasDobles;

/**
 *
 * @author CENTIC
 */
public class Main {
    
    public static void main(String[] args){
        Lista2 liston = new Lista2();
    
        liston.agregarEntero(0);//este quedaria de cola
        liston.agregarEntero(2);
        liston.agregarEntero(5);
        liston.agregarEntero(6);//por el orden de insertacion esta seria la cabeza
        liston.imprimirListaDesdeIzquierda();
        System.out.println("--------------------------");
        liston.imprimirListaDesdeDerecha();
        
        System.out.println("///////////////////////////////");
        liston.insertarNodoFinal(555);
        
        liston.imprimirListaDesdeIzquierda();
        System.out.println("--------------------------");
        liston.imprimirListaDesdeDerecha();
    }
    
}
