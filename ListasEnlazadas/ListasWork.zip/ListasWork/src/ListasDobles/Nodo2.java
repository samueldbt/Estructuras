/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListasDobles;

/**
 *
 * @author CENTIC
 */
public class Nodo2 {
    public int dato;
    public Nodo2 siguiente = null;
    public Nodo2 anterior = null;
    
    public Nodo2(int dato){
        this.dato = dato;
    }
}
