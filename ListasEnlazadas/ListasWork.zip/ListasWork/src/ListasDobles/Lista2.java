/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListasDobles;
/**
 *
 * @author CENTIC
 */
public class Lista2 {
    private Nodo2 cabeza, cola;
    public int tamaño = 0;
    
    public Lista2(){
        this.cabeza = null;
        this.cola = null;
    }
    
    public int getTamaño(){
        return tamaño;
    }
    
    public boolean estaVacia(){
        if(tamaño == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public void imprimirListaDesdeIzquierda(){
        Nodo2 nodoRecorre = cabeza;
        
        while(nodoRecorre != null){
            System.out.println(nodoRecorre.dato+" -> ");
            nodoRecorre = nodoRecorre.siguiente;
        }
        System.out.println("NULL");
    }
    
    public void imprimirListaDesdeDerecha(){
        Nodo2 nodoRecorre = cola;
        
        while(nodoRecorre != null){
            System.out.println(nodoRecorre.dato+" -> ");
            nodoRecorre = nodoRecorre.anterior;
        }
        System.out.println("NULL");
    }
    
    public void agregarEntero(int entero){
        Nodo2 nodo = new Nodo2(entero);
        if(cabeza == null){
            cabeza = nodo;
            cola = nodo;
        }else{
            nodo.siguiente = cabeza;
            this.cabeza.anterior = nodo;
            this.cabeza = nodo;
        }   
        tamaño++;
    }
    
    public void insertarNodoInicio(int dato){
        Nodo2 nuevo = new Nodo2(dato);
        if (estaVacia()){
            cola = nuevo;
        }else {
            cabeza.anterior = nuevo;
        }
        
        nuevo.siguiente = cabeza;
        nuevo.anterior = null;
        
        cabeza = nuevo;
        tamaño++;
    }
    
    public void insertarNodoFinal(int dato){
        Nodo2 nuevo = new Nodo2(dato);
        if (estaVacia()){
            cabeza = nuevo;
        }else {
            nuevo.anterior = cola;
            cola.siguiente = nuevo;
        }
        
        cola = nuevo;
        tamaño++;
    }
    
    public void insertarPorIndice(int dato, int idx){
        Nodo2 nodoParaInsertar = new Nodo2(dato);
        Nodo2 nodoRecorre = cabeza;
        
        int cont = 0;
        
        if(idx < 0 || idx > tamaño){
            System.out.println("ERROR DE INDICE");
            
        }else if(idx == 0){
            insertarNodoInicio(dato);
        }else if(idx <= tamaño){
            while (cont < (idx-1) && nodoRecorre.siguiente != null){
                nodoRecorre = nodoRecorre.siguiente;
                cont++;
            }
            nodoParaInsertar.siguiente = nodoRecorre.siguiente;
            nodoParaInsertar.anterior = nodoRecorre;
            nodoRecorre.siguiente.anterior = nodoParaInsertar;
            nodoRecorre.siguiente = nodoParaInsertar;
            
            tamaño++;
        }
    }
}
