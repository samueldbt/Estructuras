/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Colas;

/**
 *
 * @author CENTIC
 */
public class Cola {
    private Nodo inicio;
    private Nodo fin;
    private int tamaño;
    
    public Cola(){
        inicio = fin = null;
        tamaño = 0;
    }
    
    public void enqueue(int dato){ // se inserta un nodo al final de la cola
        Nodo nuevo = new Nodo(dato);
        if(estaVacia()){
            inicio = nuevo;
        }else{
            fin.siguiente = nuevo;
        }
        
        fin = nuevo;
        tamaño++;
    }
    
    public int dequeue(){ //quitar del inicio
        Nodo holder = inicio;
        
        if(estaVacia()){
            System.out.println("Lista vacia");
        }else{
            inicio = inicio.siguiente;
            holder.siguiente = null;
            tamaño--;
        }
        
        return holder.dato;
    }
    
    public void peek(){
        System.out.println("El siguiente dato es: "+inicio.dato);
    }
    
    public boolean estaVacia(){
        if(tamaño==0){
            return true;
        }else{
            return false;
        }
    }
    
    public void eliminarCola(){
        while(!estaVacia()){
        dequeue();
        }
    }
}
