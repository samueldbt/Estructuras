/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;
import java.util.LinkedList;
/**
 *
 * @author CENTIC
 */
public class GrafoListasAdyacencia {
    private LinkedList<Integer>[] adj;
    private int V;
    private int A;
    
    public GrafoListasAdyacencia(int nodos){
        this.V = nodos;
        this.A = 0;
        this.adj = new LinkedList[nodos];
        for(int v = 0; v < V; v++){
            adj[v] = new LinkedList<>();
        }
    }
    
    public void agregarArista(int u, int v){
        adj[u].add(v);
        adj[v].add(u);
        A++;
    }
    
    public void imprimirGrafo(){
        for(int v=0; v < V; v++){
            System.out.println("Row "+v+": ");
            for(int w=0; w<adj[v].size(); w++){
                System.out.println(adj[v].get(w) + "");
            }
            System.out.println("");
        }
    }
}
