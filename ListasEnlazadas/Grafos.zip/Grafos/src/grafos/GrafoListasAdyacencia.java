/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
/**
 *
 * @author CENTIC
 */
public class GrafoListasAdyacencia {
    private LinkedList<Integer>[] adj;
    private int V;
    private int A;
    
    public GrafoListasAdyacencia(int nodos){
        this.V = nodos;
        this.A = 0;
        this.adj = new LinkedList[nodos];
        for(int v = 0; v < V; v++){
            adj[v] = new LinkedList<>();
        }
    }
    
    public void agregarArista(int u, int v){
        adj[u].add(v);
        adj[v].add(u);
        A++;
    }
    
    public void imprimirGrafo(){
        for(int v=0; v < V; v++){
            System.out.println("Row "+v+": ");
            for(int w=0; w<adj[v].size(); w++){
                System.out.println(adj[v].get(w) + "");
            }
            System.out.println("");
        }
    }
    
    public void bfs(int s){
        boolean[] visited = new boolean[V];
        
        Queue<Integer> q = new LinkedList<>();
        visited[s] = true;
        q.offer(s);
        
        while(!q.isEmpty()){
            int u = q.poll();
            System.out.println(u + "");
            
            for(int v : adj[u]){
                if(!visited[v]){
                    visited[v] = true;
                    q.offer(v);
                }
            }
        }
    }
    
    public void dfs(int s){
        boolean[] visited = new boolean[V];
        Stack<Integer> stack = new Stack<>();
        stack.push(s);
        
        while(!stack.isEmpty()){
            int u = stack.pop();
            if(!visited[u]){
                visited[u] = true;
                System.out.println(u + "");
                
                for(int v : adj[u]){
                    if(!visited[v]){
                        stack.push(v);
                    }
                }
            }
        }
    }
}
