/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

/**
 *
 * @author CENTIC
 */
public class GrafoMatrizAdyacencia {
    private int V;
    private int A;
    private int[][] matrizAdyacencia;
    
    public GrafoMatrizAdyacencia(int nodos){
        this.V = nodos;
        this.A = 0;
        this.matrizAdyacencia = new int[nodos][nodos];
    }
    
    public void agregarArista(int u, int v){
        matrizAdyacencia[u][v] = 1;
        matrizAdyacencia[v][u] = 1;
        A++;
    }
    
    public void imprimirGrafo(){
        for(int v = 0; v<this.V; v++){
            System.out.println("Fila "+ v +": ");
            for(int w = 0; w < V; w++){
                System.out.println(matrizAdyacencia[v][w]+ "");
            }
            System.out.println("");
        }
        System.out.println(matrizAdyacencia[0][0]);
    }
}
