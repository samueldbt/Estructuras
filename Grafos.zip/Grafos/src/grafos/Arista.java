/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

/**
 *
 * @author PC
 */
public class Arista {
    private int destino;
    private int peso;
    
    public Arista(int d, int p){
        this.destino = d;
        this.peso = p;
    }
}
