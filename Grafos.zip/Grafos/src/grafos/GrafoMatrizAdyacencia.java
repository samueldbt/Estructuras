/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafos;

/**
 *
 * @author CENTIC
 */

//el grafo, digase la estructura total, se compone de vertices y sus conexiones
//y se representa(la estructura completa) como C=(V,A)
public class GrafoMatrizAdyacencia {
    private int V; //son los vertices o nodos, las bolitas digamos
    private int A; //son las aristas o conexiones, las rayitas que unen las bolitas
    private int[][] matrizAdyacencia;
    
    public GrafoMatrizAdyacencia(int nodos){
        this.V = nodos;//desde un principio se declara el numero de nodos que podra tener el grafo
        this.A = 0; //cada arista es representa la conexion de un par de vertices
        this.matrizAdyacencia = new int[nodos][nodos];
    }
    
    public void agregarArista(int u, int v){
        matrizAdyacencia[u][v] = 1;
        matrizAdyacencia[v][u] = 1;
        A++;
    }
    
    public void imprimirGrafo(){
        for(int v = 0; v<this.V; v++){
            System.out.println("Fila "+ v +": ");
            for(int w = 0; w < V; w++){
                System.out.println(matrizAdyacencia[v][w]+ "");
            }
            System.out.println("");
        }
        System.out.println(matrizAdyacencia[0][0]); //pq?
    }
}
