/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaenlazadasimple;

/**
 *
 * @author Samuel
 */
public class NodoPila {
    public char dato;
    public NodoPila siguiente = null;
    
    public NodoPila(char dato){
        this.dato = dato;
    }
}
