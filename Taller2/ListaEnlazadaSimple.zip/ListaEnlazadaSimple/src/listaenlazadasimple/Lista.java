package listaenlazadasimple;

/**
 *
 * @author Samuel
 */
public class Lista {
    private Nodo cabeza;
    private int size;
    public Lista(){
        this.cabeza = null; //cabeza es un puntero per se
                            //nos sirve para controlar donde empiezas
                            //la lista
        this.size = 0;
    }
    
    public int getSize(){
        return size;
    }
    
    public boolean estaVacia(){
        if(size == 0){
            return true;
        }else{
            return false;
        }
    }
    
    public void insertarNodoInicio(int dato){
        Nodo newNode = new Nodo(dato);
        newNode.siguiente = cabeza;
        cabeza = newNode;
        size++;
    }
    
    public void insertarNodoFinal(int dato){
        Nodo newNode = new Nodo(dato);
        Nodo nodoRecorre = cabeza;
        
        if(estaVacia()){
            insertarNodoInicio(dato);
        }else{
            while(nodoRecorre.siguiente != null){
                nodoRecorre = nodoRecorre.siguiente;
            }
            nodoRecorre.siguiente = newNode;
        }
    }
    
    public void imprimirLista(){
        Nodo nodoRecorre = cabeza;
        
        if(estaVacia()){
            System.out.println("Lista vacía");
        }else{
            while(nodoRecorre.siguiente != null){
                System.out.print(nodoRecorre.dato+"->");
                nodoRecorre = nodoRecorre.siguiente;
            }
            System.out.println(nodoRecorre.dato+"->null");
        }
    }
    
    public void insertarNodoIndice(int dato, int idx){
        Nodo newNode = new Nodo(dato);
        Nodo nodoRecorre = cabeza;
        
        if(estaVacia()){
            System.out.println("Lista vacía");
        }else if(idx > size){
            System.out.println("idx out of bounds");
        }else{
            int i=0;
            while(nodoRecorre.siguiente != null && i < (idx)){
                nodoRecorre = nodoRecorre.siguiente;
                i++;
            }
            newNode.siguiente = nodoRecorre.siguiente;
            nodoRecorre.siguiente = newNode;
        }
    }
    
    public void eliminarNodoInicio(){
        if(estaVacia()){
            System.out.println("nada que eliminar");
        }else{
            cabeza = cabeza.siguiente;
            size--;
        }
    }
    
    public void eliminarNodoFinal(){
        Nodo nodoRecorre = cabeza;
        
        if(estaVacia()){
            System.out.println("nada que eliminar");
        }else{
            while(nodoRecorre.siguiente.siguiente != null){
                nodoRecorre = nodoRecorre.siguiente;
            }
            nodoRecorre.siguiente = null;
            size--;
        }
    }
    
    public void eliminarNodoIndice(int idx){
        Nodo nodoRecorre = cabeza;
        
        if(estaVacia()){
            System.out.println("nada que eliminar");
        }else if(idx > size){
            System.out.println("idx out of bounds");
        }else{
            int i=0;
            while(nodoRecorre.siguiente != null && i < (idx-1)){
                nodoRecorre = nodoRecorre.siguiente;
                i++;
            }
            nodoRecorre.siguiente = nodoRecorre.siguiente.siguiente;
            size--;
        }
    }
    
    public int buscarNodo(int idx){
        Nodo nodoRecorre = cabeza;
        
        int i=0;
        while(nodoRecorre.siguiente != null && i < idx){
            nodoRecorre = nodoRecorre.siguiente;
            i++;
        }
        return nodoRecorre.dato;
    }
    
    //esto por alguna razon tiene el proposito de encontrado el nodo
    //que tiene dicho valor, busca el nodo con tal indice.
    public int buscarNodoValor(int valor){
        Nodo nodoRecorre = cabeza;
        
        int i =0;
        while(nodoRecorre.siguiente != null && nodoRecorre.dato != valor){
            nodoRecorre = nodoRecorre.siguiente;
            i++;
        }
        return i;
    }
    
    public void removerDuplicados(){
        Nodo nodoRecorre = cabeza;
        Nodo nodoSuperior = cabeza;
        Nodo marcador;
        int idxExterior = 0;
        if(estaVacia()){
            System.out.println("lista vacía");
        }else{
            while(nodoSuperior.siguiente != null){
                //este bucle funciona para eliminar las copias del primer dato
                nodoRecorre = nodoSuperior;
                marcador = nodoSuperior;
                
                int idx = idxExterior;
                while(nodoRecorre.siguiente != null){
                    if(nodoRecorre.siguiente.dato == marcador.dato){
                        eliminarNodoIndice(idx+1);
                    }else{
                        nodoRecorre = nodoRecorre.siguiente;
                        idx++;
                    }
                }
                if(nodoSuperior.siguiente == null){
                    break;
                }
                nodoSuperior = nodoSuperior.siguiente;
                idxExterior++;
            }
        }
    }
}
