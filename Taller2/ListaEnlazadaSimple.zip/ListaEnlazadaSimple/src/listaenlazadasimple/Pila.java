package listaenlazadasimple;

/**
 *
 * @author Samuel
 */
public class Pila {
    private NodoPila cima;
    private int size;
    
    public Pila(){
        cima = null;
        size = 0;
    }
    
    public boolean estaVacia(){
        return size == 0;
    }
    
    public void push(char dato){
        NodoPila newNode = new NodoPila(dato);
        newNode.siguiente = cima;
        cima = newNode;
        size++;
        System.out.print(newNode.dato);
    }
    
    public char pop(){
        NodoPila aux = cima;
        cima = cima.siguiente;
        size--;
        System.out.println("Se elimino el elemento: "+aux.dato);
        return aux.dato;
    }
    
    //hasta aqui funciona, pero tengo que hacer que lo muestre todo como una 
    //cadena y no mensajes separados
    public void revertir(String L){
        //revertir el orden de L xd
        Pila pilaRevertida = new Pila();
        
        int length = L.length();
        for(int i = length; i > 0; i--){
            pilaRevertida.push(L.charAt(i-1));
        }
        System.out.println("");
    }
    
}
