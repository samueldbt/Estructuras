package listaenlazadasimple;

/**
 *
 * @author Samuel
 */
public class Nodo {
    public int dato;
    public Nodo siguiente = null;
    
    public Nodo(int dato){
        this.dato = dato;
    }
}
