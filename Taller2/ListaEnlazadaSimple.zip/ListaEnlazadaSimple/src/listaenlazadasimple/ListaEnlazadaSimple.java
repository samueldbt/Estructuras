package listaenlazadasimple;

/**
 *
 * @author Samuel
 */
public class ListaEnlazadaSimple {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pila pila = new Pila();
        pila.revertir("Estructura de datos");
    }
    
    //codigo para probar el punto 1.1
    /*Lista lista = new Lista();
        
        lista.insertarNodoInicio(5);
        lista.insertarNodoInicio(3);//recordemos que esto pone el nodo al inicio
        lista.insertarNodoInicio(3);
        lista.insertarNodoInicio(3);
        lista.insertarNodoInicio(4);
        lista.insertarNodoInicio(4);
        lista.insertarNodoInicio(4);
        lista.insertarNodoInicio(4);
        lista.insertarNodoInicio(0);//asi que esta seria la cabeza finalmente
        lista.imprimirLista();
        //lista.eliminarNodoInicio();
        //lista.eliminarNodoFinal();
        //lista.eliminarNodoIndice(2);
        System.out.println("----------------------------------");
        lista.removerDuplicados();
        lista.imprimirLista();
        */
}
