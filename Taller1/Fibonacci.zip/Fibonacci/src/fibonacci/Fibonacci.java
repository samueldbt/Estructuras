/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fibonacci;
/**
 *
 * @author Samuel
 */
public class Fibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(fibonacciOptimizado(5));
    }
    
    public static int fibonacciOptimizado(int n){
        int fibonaciado = 0;
        if (n == 0 || n == 1){
            fibonaciado = 1;
        }else{
            fibonaciado += fibonacciOptimizado(n-1);
        }
        
        
        return fibonaciado;
    }
}
