/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comunidaduis;

/**
 *
 * @author Samuel
 */
public class EstudianteDoctorado extends Estudiante{
    
    @Override
    public void Saludar(){
        System.out.println("Hola soy estudiante de Doctorado, me llamo "+this.nombre+" "+this.apellido);
        mostrarInformacion();
    }
    
}
