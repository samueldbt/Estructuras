package comunidaduis;

public class ComunidadUis {
    public static void main(String[] args) {
        // TODO code application logic here
        EstudiantePregrado E1 = new EstudiantePregrado();
        E1.setApellido("Becerra");
        E1.setNombre("Samuel");
        E1.setPromedio(34);
        E1.setSemestre(3);
        E1.setpAcademico("Ing sistemas");
        E1.setCursos(7); 
        E1.Saludar();
        
        EstudiantePosgrado E2 = new EstudiantePosgrado();
        E2.setApellido("Toro");
        E2.setNombre("Daniel");
        E2.setPromedio(34);
        E2.setSemestre(3);
        E2.setpAcademico("Ing industrial");
        E2.setCursos(7); 
        E2.Saludar();
        
        EstudianteMaestria E3 = new EstudianteMaestria();
        E3.setApellido("Becerra");
        E3.setNombre("Carlos");
        E3.setPromedio(34);
        E3.setSemestre(3);
        E3.setpAcademico("Maestria de educacion");
        E3.setCursos(7); 
        E3.Saludar();
        
        EstudianteDoctorado E4 = new EstudianteDoctorado();
        E4.setApellido("Toro");
        E4.setNombre("Esperanza");
        E4.setPromedio(34);
        E4.setSemestre(3);
        E4.setpAcademico("Doctorado de supercomputacion");
        E4.setCursos(7); 
        E4.Saludar();
        
        //ahora los empleados
        Profesor P1 = new Profesor();
        P1.setApellido("Barrios");
        P1.setNombre("Cornelio");
        P1.setEdadLaboral(3);
        P1.setSalario(5000);
        P1.setUAA("Planta");
        P1.Saludar();
        
        Administrativo A1 = new Administrativo();
        A1.setApellido("Barrios");
        A1.setNombre("Visitacion");
        A1.setEdadLaboral(5);
        A1.setSalario(8000);
        A1.setUAA("Extranjerismos");
        A1.Saludar();
    }
}
