/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comunidaduis;

/**
 *
 * @author Samuel
 */

//estos atributos son particulares para cada estudiante
public class Empleado extends Persona{
    protected float salario;
    protected String UAA;
    protected int edadLaboral;

    public float getSalario() {
        return salario;
    }

    public String getUAA() {
        return UAA;
    }

    public int getEdadLaboral() {
        return edadLaboral;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public void setUAA(String UAA) {
        this.UAA = UAA;
    }

    public void setEdadLaboral(int edadLaboral) {
        this.edadLaboral = edadLaboral;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    
    @Override
    public void Saludar(){
        System.out.println("Hola! Soy un empleado");
    }
    
    public void mostrarInformacion(){
        System.out.println("Tengo "+this.salario+" de salario");
        System.out.println("Mi UAA es: "+this.UAA);
        System.out.println("Voy llevo trabajando "+this.edadLaboral+" años");
        System.out.println("----------------------------------------------------------------------------------");
    }    
}
