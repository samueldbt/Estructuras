/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comunidaduis;

/**
 *
 * @author Samuel
 */

//estos atributos son particulares para cada estudiante
public class Estudiante extends Persona{
    protected int cursos;
    protected float promedio;
    protected int semestre;
    protected String pAcademico;   
    
    

    public int getCursos() {
        return cursos;
    }

    public float getPromedio() {
        return promedio;
    }

    public int getSemestre() {
        return semestre;
    }

    public String getpAcademico() {
        return pAcademico;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setCursos(int cursos) {
        this.cursos = cursos;
    }

    public void setPromedio(float promedio) {
        this.promedio = promedio;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public void setpAcademico(String pAcademico) {
        this.pAcademico = pAcademico;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    @Override
    public void Saludar(){
        System.out.println("Hola! Soy un estudiante");      
    }
    
    public void mostrarInformacion(){
        System.out.println("Estoy viendo "+this.cursos+" cursos");
        System.out.println("Mi promedio es "+this.promedio);
        System.out.println("Voy en el semestre "+this.semestre);
        System.out.println("Mi programa academico es "+this.pAcademico);
        System.out.println("----------------------------------------------------------------------------------");
    }
}
