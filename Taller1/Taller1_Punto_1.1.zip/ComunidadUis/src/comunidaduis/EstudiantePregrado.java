/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comunidaduis;

/**
 *
 * @author Samuel
 */
public class EstudiantePregrado extends Estudiante{

    @Override 
    public void Saludar(){
        System.out.println("Hola soy estudiante de pregrado, me llamo "+this.nombre+" "+this.apellido);
        mostrarInformacion();
    }
}
