package comunidaduis;

/**
 *
 * @author Samuel
 */

/*esta clase tiene de hija a Estudiante y Empleado, y estas tienen 
sus respectivas hijas*/
public abstract class Persona {
    protected String nombre;
    protected String apellido;
    protected int edad;
    
    //cada una de las clases tiene su forma de saludar
    public abstract void Saludar();
        
    
}
