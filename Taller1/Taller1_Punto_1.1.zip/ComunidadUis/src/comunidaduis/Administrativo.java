/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comunidaduis;

/**
 *
 * @author Samuel
 */
public class Administrativo extends Empleado{
    @Override
    public void Saludar(){
        System.out.println("Hola soy un administrativo, me llamo "+this.nombre+" "+this.apellido);
        mostrarInformacion();
    }
}
