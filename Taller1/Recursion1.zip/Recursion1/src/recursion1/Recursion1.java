/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recursion1;

/**
 *
 * @author Samuel
 */
public class Recursion1 {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(encontrarSuma(8));
    }
    
    public static int encontrarSuma(int n){
        int suma = 0;
        if(n == 1){//valor base
            suma = 1;
        }else{
            suma += n + encontrarSuma(n-1);
        }
        return suma;
    }
    
}
