/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenamiento;
/**
 *
 * @author Samuel
 */

import java.util.Arrays;
public class Ordenamiento {

    public static void main(String[] args) {
        // TODO code application logic here
        int[] listaNumeros = {2, 4, 5, 3, 1, 6, 7};
        String[] Cadena = {"a","b","c","d","e","f", "g"};
        String A = "Ascendente";
        String D = "Descendente";
        
        /*DE FORMA ASCENDENTE FUNCIONA BIEN*/
        System.out.println(Arrays.toString(ordenarNumeros(listaNumeros, D)));
        System.out.println(Arrays.toString(ordenarStrings(Cadena, D)));
    }
    
    public static int[] ordenarNumeros(int[] vector, String tipoOrden){
        if(tipoOrden.equals("Ascendente")){
            Arrays.sort(vector);
        }else if (tipoOrden.equals("Descendente")){
            //ordenar de forma descendente
            int m;
            
            for(int i=0;i<vector.length;i++){
                for(int j=0;j<vector.length;j++){
                    //comparacion de componentes y cambio de lugares
                    if(vector[i] > vector[j]){
                        m = vector[i];
                        vector[i] = vector[j];
                        vector[j] = m;
                    }
                }
            }
        }
        return vector;
    }
    
    public static String[] ordenarStrings(String[] vector, String tipoOrden){
        if(tipoOrden.equals("Ascendente")){
            Arrays.sort(vector);
        }else if (tipoOrden.equals("Descendente")){
            //ordenar de forma descendente
            
        }
        
        return vector;
        
    }
}
